# GUARDIAN Security Review

## Findings

### GUARDIAN-001: Hardcoded API Key [BLOCKER]

**File:** src/config.js
**Line:** 42

**Evidence:** `const API_KEY = "sk-proj-abc123..."`

API key is hardcoded in source code, exposing credentials in version control.

**Remediation:** Move to environment variable or secrets manager.

### GUARDIAN-002: SQL Injection Risk [HIGH]

**File:** src/db/queries.js
**Line:** 87

**Evidence:** `query = "SELECT * FROM users WHERE id=" + userId`

User input is concatenated directly into SQL query string.

**Remediation:** Use parameterized queries or an ORM.

### GUARDIAN-003: Missing HTTPS Enforcement [MEDIUM]

**File:** src/api/client.js
**Line:** 12

HTTP endpoints used for API calls. Data transmitted in plaintext.

**Remediation:** Update all endpoints to HTTPS. Add HSTS headers.

### GUARDIAN-004: Verbose Error Messages [LOW]

**File:** src/middleware/error-handler.js
**Line:** 28

Stack traces exposed in production error responses.

**Remediation:** Return generic error messages in production.

## Summary
| Severity | Count |
|----------|-------|
| BLOCKER | 1 |
| HIGH | 1 |
| MEDIUM | 1 |
| LOW | 1 |

**Verdict: HOLD**
